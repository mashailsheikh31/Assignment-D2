# Intern Attendance Management System

**Intern Name:** Mashail Abdul Khaliq 
**Role:** Web Development Intern  
**Technologies:** HTML5, CSS3, JavaScript (ES6)  
**Repository:** `glavion-intern-attendance-system`

## Features
- **Authentication View:** Client-side email and password form validation.
- **Attendance Controls:** Dynamic Check-In and Check-Out with live time timestamps.
- **Dashboard Stats:** High-level summary of total working days, presents, absentees, lates, and overall percentage.
- **Responsive Layout:** Dynamic horizontal table scrolling for mobile screens and a toggleable CSS drawer menu.

## Setup Instructions
1. Clone the repository: `git clone https://github.com/mashailsheikh31/glavion1`
2. Open `index.html` directly in any standard browser (Chrome, Edge, Firefox).

## Future Improvements
- Implement `localStorage` to save marked check-in times across browser sessions.
- Integrate dynamic percentage calculations and a light/dark mode switch.


---
