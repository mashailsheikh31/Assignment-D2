// Initial Dummy History Records
const initialHistory = [
  { date: '28 Aug 2026', checkIn: '09:02 AM', checkOut: '05:04 PM', status: 'Present' },
  { date: '27 Aug 2026', checkIn: '09:18 AM', checkOut: '05:10 PM', status: 'Late' },
  { date: '26 Aug 2026', checkIn: '09:00 AM', checkOut: '05:00 PM', status: 'Present' },
  { date: '25 Aug 2026', checkIn: '--', checkOut: '--', status: 'Absent' }
];

document.addEventListener('DOMContentLoaded', () => {
  initStorage();
  startLiveClock();
  setupMobileDrawer();
  setupAuth();
  setupAttendanceEngine();
  renderAnalyticsAndTable();
});

// Seed LocalStorage if empty
function initStorage() {
  if (!localStorage.getItem('attendanceHistory')) {
    localStorage.setItem('attendanceHistory', JSON.stringify(initialHistory));
  }
}

// Task 2: Ticking Clock & Formatted Date
function startLiveClock() {
  const clockEl = document.getElementById('live-clock');
  const dateEl = document.getElementById('today-date');

  function update() {
    const now = new Date();
    if (clockEl) {
      clockEl.textContent = now.toLocaleTimeString('en-US', { hour12: true });
    }
    if (dateEl) {
      dateEl.textContent = now.toLocaleDateString('en-GB', {
        weekday: 'long', day: 'numeric', month: 'long', year: 'numeric'
      });
    }
  }
  update();
  setInterval(update, 1000);
}

// Task 1: Check In / Check Out State Persistence
function setupAttendanceEngine() {
  const checkInBtn = document.getElementById('check-in-btn');
  const checkOutBtn = document.getElementById('check-out-btn');
  const statusDisplay = document.getElementById('attendance-status');
  const checkInTimeText = document.getElementById('check-in-time');
  const checkOutTimeText = document.getElementById('check-out-time');

  if (!checkInBtn || !checkOutBtn) return;

  const todayStr = new Date().toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' });
  const savedState = JSON.parse(localStorage.getItem('todayAttendance'));

  // Load saved state on page load
  if (savedState && savedState.date === todayStr) {
    statusDisplay.textContent = savedState.status;
    statusDisplay.className = `badge badge-${savedState.status.toLowerCase()}`;
    checkInTimeText.textContent = savedState.checkIn || '--:--';
    checkOutTimeText.textContent = savedState.checkOut || '--:--';

    if (savedState.checkIn) {
      checkInBtn.disabled = true;
      checkOutBtn.disabled = false;
    }
    if (savedState.checkOut) {
      checkOutBtn.disabled = true;
    }
  }

  // Check In Event
  checkInBtn.addEventListener('click', () => {
    const now = new Date();
    const timeStr = now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    
    // Determine if Late (e.g., after 9:15 AM)
    const isLate = now.getHours() > 9 || (now.getHours() === 9 && now.getMinutes() > 15);
    const status = isLate ? 'Late' : 'Present';

    const state = { date: todayStr, checkIn: timeStr, checkOut: null, status: status };
    localStorage.setItem('todayAttendance', JSON.stringify(state));

    statusDisplay.textContent = status;
    statusDisplay.className = `badge badge-${status.toLowerCase()}`;
    checkInTimeText.textContent = timeStr;

    checkInBtn.disabled = true;
    checkOutBtn.disabled = false;
  });

  // Check Out Event & History Injection
  checkOutBtn.addEventListener('click', () => {
    const timeStr = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    const savedState = JSON.parse(localStorage.getItem('todayAttendance'));
    
    savedState.checkOut = timeStr;
    localStorage.setItem('todayAttendance', JSON.stringify(savedState));

    checkOutTimeText.textContent = timeStr;
    checkOutBtn.disabled = true;

    // Task 4: Add to History Array & Re-render
    let history = JSON.parse(localStorage.getItem('attendanceHistory')) || [];
    history = history.filter(item => item.date !== savedState.date); // replace existing today entry if any
    history.unshift(savedState);
    
    localStorage.setItem('attendanceHistory', JSON.stringify(history));
    renderAnalyticsAndTable();
  });
}

// Task 3 & 4: Dynamic Analytics & Dynamic History Rows Injection
function renderAnalyticsAndTable() {
  const history = JSON.parse(localStorage.getItem('attendanceHistory')) || [];
  const tableBody = document.getElementById('history-table-body');

  // Render Table Rows Dynamically
  if (tableBody) {
    tableBody.innerHTML = '';
    history.forEach(record => {
      const row = `
        <tr>
          <td>${record.date}</td>
          <td>${record.checkIn}</td>
          <td>${record.checkOut || '--'}</td>
          <td><span class="badge badge-${record.status.toLowerCase()}">${record.status}</span></td>
        </tr>
      `;
      tableBody.insertAdjacentHTML('beforeend', row);
    });
  }

  // Calculate Metrics
  const totalDays = history.length;
  const presentCount = history.filter(r => r.status === 'Present').length;
  const lateCount = history.filter(r => r.status === 'Late').length;
  const absentCount = history.filter(r => r.status === 'Absent').length;
  
  const percentage = totalDays > 0 
    ? (((presentCount + lateCount) / totalDays) * 100).toFixed(1) 
    : '0.0';

  // Update Dashboard UI
  if (document.getElementById('stat-total')) document.getElementById('stat-total').textContent = totalDays;
  if (document.getElementById('stat-present')) document.getElementById('stat-present').textContent = presentCount;
  if (document.getElementById('stat-absent')) document.getElementById('stat-absent').textContent = absentCount;
  if (document.getElementById('stat-late')) document.getElementById('stat-late').textContent = lateCount;
  
  const pctEl = document.getElementById('stat-pct');
  const progressBar = document.getElementById('progress-bar');
  
  if (pctEl) pctEl.textContent = `${percentage}%`;
  
  if (progressBar) {
    progressBar.style.width = `${percentage}%`;
    progressBar.style.backgroundColor = parseFloat(percentage) >= 80 ? 'var(--success)' : 'var(--warning)';
  }
}

// Mobile Drawer & Overlay Management (Audit Finding B)
function setupMobileDrawer() {
  const menuToggle = document.getElementById('menu-toggle');
  const sidebar = document.querySelector('.sidebar');
  const overlay = document.getElementById('sidebar-overlay');

  function toggle() {
    sidebar.classList.toggle('active');
    overlay.classList.toggle('active');
  }

  if (menuToggle) menuToggle.addEventListener('click', toggle);
  if (overlay) overlay.addEventListener('click', toggle);
}

// Login Handling
function setupAuth() {
  const loginForm = document.getElementById('login-form');
  if (loginForm) {
    loginForm.addEventListener('submit', (e) => {
      e.preventDefault();
      const email = document.getElementById('email').value.trim();
      const password = document.getElementById('password').value.trim();
      const errorElement = document.getElementById('login-error');

      if (!email || !password) {
        errorElement.textContent = 'Please enter both email and password.';
        errorElement.style.display = 'block';
      } else {
        errorElement.style.display = 'none';
        window.location.href = 'dashboard.html';
      }
    });
  }
}